package com.aaoseekho.english;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback;

import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.UnityAdsShowOptions;
import com.unity3d.services.banners.BannerErrorInfo;
import com.unity3d.services.banners.BannerView;
import com.unity3d.services.banners.UnityBannerSize;

import com.startapp.sdk.adsbase.Ad;
import com.startapp.sdk.adsbase.StartAppAd;
import com.startapp.sdk.adsbase.adlisteners.AdEventListener;
import com.startapp.sdk.adsbase.adlisteners.VideoListener;
import com.startapp.sdk.ads.banner.Banner;

/**
 * तीनों नेटवर्क (AdMob, Unity, Start.io) की बारी-बारी (rotation) + फ़ॉलबैक।
 * एक समय में सिर्फ़ एक फुल-स्क्रीन ऐड चलता है। दो फुल-स्क्रीन ऐड के बीच GAP_MS का अंतर।
 */
public class AdManager {
    // ---- यहाँ से बदल सकते हो ----
    static final long GAP_MS = 30000; // दो interstitial के बीच कम से कम 30 सेकंड
    // ------------------------------
    static final String AM_BANNER = "ca-app-pub-1493112125477027/2647803420";
    static final String AM_INTER = "ca-app-pub-1493112125477027/3904955481";
    static final String AM_REWARD = "ca-app-pub-1493112125477027/5172885252";
    static final String AM_RI = "ca-app-pub-1493112125477027/9085129974";
    static final String AM_OPEN = "ca-app-pub-1493112125477027/6890211479";
    static final String UN_GAME = "800379873";
    static final String UN_BANNER = "BP_Banner_Android";
    static final String UN_INTER = "BP_Interstitial_Android";
    static final String UN_REWARD = "BP_Rewarded_Android";

    final Activity act;
    final WebView web;
    final FrameLayout bannerBox;
    final Handler ui = new Handler(Looper.getMainLooper());

    InterstitialAd amInter;
    RewardedAd amReward;
    RewardedInterstitialAd amRI;
    AppOpenAd amOpen;
    boolean unityReady = false, unInter = false, unReward = false;
    StartAppAd stInter, stReward;
    boolean stInterReady = false, stRewardReady = false;
    long lastFull = 0;
    int rot = 0;
    boolean openShown = false;
    String pendingTag = "heart";

    AdManager(Activity a, WebView w, FrameLayout box) { act = a; web = w; bannerBox = box; }

    // ================= INIT =================
    void init() {
        MobileAds.initialize(act, status -> ui.post(() -> {
            loadAmInter(); loadAmReward(); loadAmRI(); loadAmOpen();
            loadBanner();
        }));
        UnityAds.initialize(act.getApplicationContext(), UN_GAME, false, new IUnityAdsInitializationListener() {
            @Override public void onInitializationComplete() { ui.post(() -> { unityReady = true; loadUnInter(); loadUnReward(); }); }
            @Override public void onInitializationFailed(UnityAds.UnityAdsInitializationError e, String m) { }
        });
        loadStInter();
        loadStReward();
    }

    // ================= BANNER (नीचे की पट्टी): AdMob -> Unity -> Start.io =================
    void loadBanner() {
        bannerBox.removeAllViews();
        AdView v = new AdView(act);
        v.setAdSize(AdSize.BANNER);
        v.setAdUnitId(AM_BANNER);
        v.setAdListener(new AdListener() {
            @Override public void onAdFailedToLoad(LoadAdError e) { ui.post(() -> unityBanner()); }
        });
        bannerBox.addView(v, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT, android.view.Gravity.CENTER));
        v.loadAd(new AdRequest.Builder().build());
    }

    void unityBanner() {
        if (!unityReady) { startBanner(); return; }
        bannerBox.removeAllViews();
        BannerView bv = new BannerView(act, UN_BANNER, new UnityBannerSize(320, 50));
        bv.setListener(new BannerView.IListener() {
            @Override public void onBannerLoaded(BannerView b) { }
            @Override public void onBannerShown(BannerView b) { }
            @Override public void onBannerClick(BannerView b) { }
            @Override public void onBannerFailedToLoad(BannerView b, BannerErrorInfo e) { ui.post(() -> startBanner()); }
            @Override public void onBannerLeftApplication(BannerView b) { }
        });
        bannerBox.addView(bv, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT, android.view.Gravity.CENTER));
        bv.load();
    }

    void startBanner() {
        bannerBox.removeAllViews();
        Banner b = new Banner(act);
        bannerBox.addView(b, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT, android.view.Gravity.CENTER));
    }

    // ================= ADMOB लोडर =================
    void loadAmInter() {
        InterstitialAd.load(act, AM_INTER, new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
            @Override public void onAdLoaded(InterstitialAd ad) { amInter = ad; }
            @Override public void onAdFailedToLoad(LoadAdError e) { amInter = null; }
        });
    }
    void loadAmReward() {
        RewardedAd.load(act, AM_REWARD, new AdRequest.Builder().build(), new RewardedAdLoadCallback() {
            @Override public void onAdLoaded(RewardedAd ad) { amReward = ad; }
            @Override public void onAdFailedToLoad(LoadAdError e) { amReward = null; }
        });
    }
    void loadAmRI() {
        RewardedInterstitialAd.load(act, AM_RI, new AdRequest.Builder().build(), new RewardedInterstitialAdLoadCallback() {
            @Override public void onAdLoaded(RewardedInterstitialAd ad) { amRI = ad; }
            @Override public void onAdFailedToLoad(LoadAdError e) { amRI = null; }
        });
    }
    void loadAmOpen() {
        AppOpenAd.load(act, AM_OPEN, new AdRequest.Builder().build(), new AppOpenAd.AppOpenAdLoadCallback() {
            @Override public void onAdLoaded(AppOpenAd ad) {
                amOpen = ad;
                if (!openShown) {
                    openShown = true;
                    lastFull = System.currentTimeMillis();
                    ad.show(act);
                }
            }
            @Override public void onAdFailedToLoad(LoadAdError e) { amOpen = null; }
        });
    }

    // ================= UNITY लोडर =================
    void loadUnInter() {
        UnityAds.load(UN_INTER, new IUnityAdsLoadListener() {
            @Override public void onUnityAdsAdLoaded(String p) { unInter = true; }
            @Override public void onUnityAdsFailedToLoad(String p, UnityAds.UnityAdsLoadError e, String m) { unInter = false; }
        });
    }
    void loadUnReward() {
        UnityAds.load(UN_REWARD, new IUnityAdsLoadListener() {
            @Override public void onUnityAdsAdLoaded(String p) { unReward = true; }
            @Override public void onUnityAdsFailedToLoad(String p, UnityAds.UnityAdsLoadError e, String m) { unReward = false; }
        });
    }

    // ================= START.IO लोडर =================
    void loadStInter() {
        stInterReady = false;
        stInter = new StartAppAd(act);
        stInter.loadAd(new AdEventListener() {
            @Override public void onReceiveAd(Ad ad) { stInterReady = true; }
            @Override public void onFailedToReceiveAd(Ad ad) { stInterReady = false; }
        });
    }
    void loadStReward() {
        stRewardReady = false;
        stReward = new StartAppAd(act);
        stReward.setVideoListener(new VideoListener() {
            @Override public void onVideoCompleted() { giveReward(); }
        });
        stReward.loadAd(StartAppAd.AdMode.REWARDED_VIDEO, new AdEventListener() {
            @Override public void onReceiveAd(Ad ad) { stRewardReady = true; }
            @Override public void onFailedToReceiveAd(Ad ad) { stRewardReady = false; }
        });
    }

    // ================= JS से आने वाला हुक्म =================
    void show(String kind) {
        ui.post(() -> {
            try {
                long now = System.currentTimeMillis();
                if ("interstitial".equals(kind)) {
                    if (now - lastFull >= GAP_MS) tryInter();
                } else if ("rewarded".equals(kind)) {
                    showRewarded("heart", false);
                } else if ("rewardedInterstitial".equals(kind)) {
                    showRewarded("bonus", true);
                } else if ("banner".equals(kind)) {
                    loadBanner();
                }
            } catch (Exception e) { /* ऐप कभी नहीं टूटेगा */ }
        });
    }

    // ================= INTERSTITIAL: बारी-बारी + फ़ॉलबैक =================
    boolean tryInter() {
        for (int i = 0; i < 3; i++) {
            int n = (rot + i) % 3;
            if (showInterBy(n)) { rot = (n + 1) % 3; lastFull = System.currentTimeMillis(); return true; }
        }
        return false;
    }

    boolean showInterBy(int n) {
        if (n == 0) {
            if (amInter == null) return false;
            InterstitialAd ad = amInter; amInter = null;
            ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override public void onAdDismissedFullScreenContent() { loadAmInter(); }
                @Override public void onAdFailedToShowFullScreenContent(AdError e) { loadAmInter(); }
            });
            ad.show(act);
            return true;
        }
        if (n == 1) {
            if (!(unityReady && unInter)) return false;
            unInter = false;
            UnityAds.show(act, UN_INTER, new UnityAdsShowOptions(), new IUnityAdsShowListener() {
                @Override public void onUnityAdsShowFailure(String p, UnityAds.UnityAdsShowError e, String m) { loadUnInter(); }
                @Override public void onUnityAdsShowStart(String p) { }
                @Override public void onUnityAdsShowClick(String p) { }
                @Override public void onUnityAdsShowComplete(String p, UnityAds.UnityAdsShowCompletionState s) { loadUnInter(); }
            });
            return true;
        }
        if (!stInterReady) return false;
        stInterReady = false;
        stInter.showAd();
        ui.postDelayed(this::loadStInter, 3000);
        return true;
    }

    // ================= REWARDED: दिल / बोनस (यूज़र की मर्ज़ी से) =================
    void showRewarded(String tag, boolean preferRI) {
        pendingTag = tag;
        if (preferRI && amRI != null) {
            RewardedInterstitialAd ad = amRI; amRI = null;
            ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override public void onAdDismissedFullScreenContent() { loadAmRI(); }
                @Override public void onAdFailedToShowFullScreenContent(AdError e) { loadAmRI(); }
            });
            ad.show(act, item -> giveReward());
            lastFull = System.currentTimeMillis();
            return;
        }
        for (int i = 0; i < 3; i++) {
            int n = (rot + i) % 3;
            if (n == 0 && amReward != null) {
                RewardedAd ad = amReward; amReward = null;
                ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override public void onAdDismissedFullScreenContent() { loadAmReward(); }
                    @Override public void onAdFailedToShowFullScreenContent(AdError e) { loadAmReward(); }
                });
                ad.show(act, item -> giveReward());
                rot = 1; lastFull = System.currentTimeMillis();
                return;
            }
            if (n == 1 && unityReady && unReward) {
                unReward = false;
                UnityAds.show(act, UN_REWARD, new UnityAdsShowOptions(), new IUnityAdsShowListener() {
                    @Override public void onUnityAdsShowFailure(String p, UnityAds.UnityAdsShowError e, String m) { loadUnReward(); }
                    @Override public void onUnityAdsShowStart(String p) { }
                    @Override public void onUnityAdsShowClick(String p) { }
                    @Override public void onUnityAdsShowComplete(String p, UnityAds.UnityAdsShowCompletionState s) {
                        if (s == UnityAds.UnityAdsShowCompletionState.COMPLETED) giveReward();
                        loadUnReward();
                    }
                });
                rot = 2; lastFull = System.currentTimeMillis();
                return;
            }
            if (n == 2 && stRewardReady) {
                stRewardReady = false;
                stReward.showAd();
                ui.postDelayed(this::loadStReward, 3000);
                rot = 0; lastFull = System.currentTimeMillis();
                return;
            }
        }
        Toast.makeText(act, "ऐड अभी तैयार नहीं है, थोड़ी देर बाद कोशिश करो 🙏", Toast.LENGTH_LONG).show();
    }

    void giveReward() {
        final String tag = pendingTag;
        ui.post(() -> web.evaluateJavascript("window.onRewardEarned&&window.onRewardEarned('" + tag + "')", null));
    }
}
