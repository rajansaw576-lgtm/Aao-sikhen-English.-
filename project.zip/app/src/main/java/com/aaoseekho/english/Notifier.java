package com.aaoseekho.english;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import org.json.JSONArray;
import org.json.JSONObject;

public class Notifier {
    static PendingIntent pi(Context c, int id, String title, String body) {
        Intent i = new Intent(c, NotifReceiver.class);
        i.putExtra("id", id);
        i.putExtra("title", title);
        i.putExtra("body", body);
        return PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void schedule(Context c, String json) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            for (int id = 9101; id <= 9140; id++) am.cancel(pi(c, id, "", ""));
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                int id = o.getInt("id");
                long at = o.getLong("at");
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c, id, o.getString("title"), o.getString("body")));
            }
        } catch (Exception e) { /* चुपचाप */ }
    }
}
