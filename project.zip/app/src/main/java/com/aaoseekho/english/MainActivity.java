package com.aaoseekho.english;

import android.app.Activity;
import android.os.Bundle;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

public class MainActivity extends Activity {
    WebView web;
    FrameLayout bannerBox;
    AdManager ads;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        web = new WebView(this);
        root.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // बैनर हमेशा सबसे नीचे एक तय पट्टी में रहता है — लेवल के बटन नहीं ढकते
        bannerBox = new FrameLayout(this);
        int h = (int) (50 * getResources().getDisplayMetrics().density);
        root.addView(bannerBox, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());

        ads = new AdManager(this, web, bannerBox);
        Bridge br = new Bridge(this, ads);
        web.addJavascriptInterface(br, "NativeAdBridge");
        web.addJavascriptInterface(br, "NativeNotifyBridge");
        web.loadUrl("file:///android_asset/index.html");
        ads.init();
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript(
            "(function(){var l=document.getElementById('lesson');if(l&&l.classList.contains('show')){closeLesson();return 1;}return 0;})()",
            value -> { if (!"1".equals(value)) finish(); });
    }
}
