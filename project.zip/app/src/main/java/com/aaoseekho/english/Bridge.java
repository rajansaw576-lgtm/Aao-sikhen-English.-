package com.aaoseekho.english;

import android.Manifest;
import android.app.Activity;
import android.os.Build;
import android.webkit.JavascriptInterface;

public class Bridge {
    final Activity act;
    final AdManager ads;

    Bridge(Activity a, AdManager m) { act = a; ads = m; }

    @JavascriptInterface
    public void show(String kind) { ads.show(kind); }

    @JavascriptInterface
    public void requestPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            act.runOnUiThread(() -> act.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 77));
        }
    }

    @JavascriptInterface
    public void schedule(String json) { Notifier.schedule(act, json); }
}
