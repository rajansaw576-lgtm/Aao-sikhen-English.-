package com.aaoseekho.english;

import android.app.Activity;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import java.util.Locale;

public class TtsBridge {
    TextToSpeech tts;
    boolean ready = false;

    TtsBridge(Activity act) {
        tts = new TextToSpeech(act, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(Locale.US);
                ready = (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED);
            }
        });
    }

    @JavascriptInterface
    public void speak(String text) {
        if (tts != null && ready && text != null && text.length() > 0) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "utt1");
        }
    }

    void shutdown() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
    }
}
