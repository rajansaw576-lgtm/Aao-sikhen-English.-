package com.aaoseekho.english;

import android.app.Activity;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import java.util.Locale;

public class TtsBridge {
    TextToSpeech tts;
    boolean ready = false;
    boolean hindiOk = false;

    TtsBridge(Activity act) {
        tts = new TextToSpeech(act, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(Locale.US);
                ready = (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED);
                int rh = tts.isLanguageAvailable(new Locale("hi", "IN"));
                hindiOk = (rh == TextToSpeech.LANG_AVAILABLE || rh == TextToSpeech.LANG_COUNTRY_AVAILABLE
                        || rh == TextToSpeech.LANG_COUNTRY_VAR_AVAILABLE);
            }
        });
    }

    // देवनागरी अक्षर मिलें तो हिंदी समझो, वरना अंग्रेज़ी
    static boolean isHindi(String text) {
        if (text == null) return false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c >= '\u0900' && c <= '\u097F') return true;
        }
        return false;
    }

    @JavascriptInterface
    public void speak(String text) {
        if (tts != null && ready && text != null && text.length() > 0) {
            if (isHindi(text) && hindiOk) {
                tts.setLanguage(new Locale("hi", "IN"));
            } else {
                tts.setLanguage(Locale.US);
            }
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "utt1");
        }
    }

    void shutdown() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
    }
}
